//
//  ViewController.h
//  ArcFace
//
//  Created by yalichen on 2017/7/31.
//  Copyright © 2017年 ArcSoft. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

