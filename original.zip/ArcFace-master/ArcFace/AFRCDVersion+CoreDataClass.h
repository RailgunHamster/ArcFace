//
//  AFRCDVersion+CoreDataClass.h
//  
//
//  Created by yalichen on 17/5/3.
//
//  This file was automatically generated and should not be edited.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

NS_ASSUME_NONNULL_BEGIN

@interface AFRCDVersion : NSManagedObject

@end

NS_ASSUME_NONNULL_END

#import "AFRCDVersion+CoreDataProperties.h"
