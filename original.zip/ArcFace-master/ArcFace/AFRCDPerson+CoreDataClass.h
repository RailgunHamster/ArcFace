//
//  AFRCDPerson+CoreDataClass.h
//  
//
//  Created by clin on 4/1/17.
//
//  This file was automatically generated and should not be edited.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

NS_ASSUME_NONNULL_BEGIN

@interface AFRCDPerson : NSManagedObject

@end

NS_ASSUME_NONNULL_END

#import "AFRCDPerson+CoreDataProperties.h"
