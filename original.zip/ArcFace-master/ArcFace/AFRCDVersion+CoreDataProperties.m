//
//  AFRCDVersion+CoreDataProperties.m
//  
//
//  Created by yalichen on 17/5/3.
//
//  This file was automatically generated and should not be edited.
//

#import "AFRCDVersion+CoreDataProperties.h"

@implementation AFRCDVersion (CoreDataProperties)

+ (NSFetchRequest<AFRCDVersion *> *)fetchRequest {
	return [[NSFetchRequest alloc] initWithEntityName:@"AFRCDVersion"];
}

@dynamic frmodelversion;
@dynamic version;

@end
