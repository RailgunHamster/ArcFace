//
//  AFRCDPerson+CoreDataClass.m
//  
//
//  Created by clin on 4/1/17.
//
//  This file was automatically generated and should not be edited.
//

#import "AFRCDPerson+CoreDataClass.h"

@implementation AFRCDPerson

@end
