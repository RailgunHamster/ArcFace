//
//  AFRCDVersion+CoreDataClass.m
//  
//
//  Created by yalichen on 17/5/3.
//
//  This file was automatically generated and should not be edited.
//

#import "AFRCDVersion+CoreDataClass.h"

@implementation AFRCDVersion

@end
