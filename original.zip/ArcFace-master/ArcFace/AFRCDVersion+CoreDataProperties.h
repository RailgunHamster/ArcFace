//
//  AFRCDVersion+CoreDataProperties.h
//  
//
//  Created by yalichen on 17/5/3.
//
//  This file was automatically generated and should not be edited.
//

#import "AFRCDVersion+CoreDataClass.h"


NS_ASSUME_NONNULL_BEGIN

@interface AFRCDVersion (CoreDataProperties)

+ (NSFetchRequest<AFRCDVersion *> *)fetchRequest;

@property (nonatomic) int32_t frmodelversion;
@property (nonatomic) int32_t version;

@end

NS_ASSUME_NONNULL_END
