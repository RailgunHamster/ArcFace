//
//  StaticImageViewController.h
//  ArcFace
//
//  Created by yalichen on 2018/2/5.
//  Copyright © 2018年 ArcSoft. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface StaticImageViewController : UIViewController

@end
